# :sparkles: spacekitties :sparkles:
A new Flutter application that assists college students during COVID-19 with adjusting to their new community.

## Project Status
Development in process and ongoing.

## The Problem
In terms of safety and social networking, college students often have a difficult time settling into their new community, especially during this COVID-19 pandemic. This app's target audience is college students with the purpose
to help them better settle to a safe, enjoyable college community.

## To-Do List

## Getting Started

## Roles
Soyon Kim, Jennifer Trinh, Cynthia Osuji, Stacy Menendez
