package com.example.spacekitties

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
